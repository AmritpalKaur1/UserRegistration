// middleware function to check for logged-in users
exports.sessionChecker = (req, res, next) => {
    if (!req.session.isLoggedIn) {
        res.redirect('/login');
    }
    next();
  };
  
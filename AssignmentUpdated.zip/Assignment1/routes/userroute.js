const express  = require('express')
const router = express.Router()
const {body}=require('express-validator/check')
var users_model = require('../models/usermodel')
var usersControl = require('../controllers/usercontroller')
var sessionCheck = require('../middlewares/middle')



//GET ROUTE FOR HOME PAGE
  router.get('/',usersControl.homes)

  //GET ROUTE FOR SIGNUP
router.get('/signup',(req,res,next)=>{
  const isLoggedIn= req.session.isLoggedIn;
  res.render('form',
  {
    title:'Register',
    isLoggedIn:isLoggedIn
  })
})

//GET ROUTE FOR LOGIN
router.get('/login',(req,res,next)=>{
  const isLoggedIn= req.session.isLoggedIn;
    res.render('login',
    {
      title:'Login',
      isLoggedIn:isLoggedIn
    })
  })

//POST ROUTE FOR SIGNUP
router.post('/signup',usersControl.home)

//POST ROUTE FOR LOGIN
router.post("/login",usersControl.login)

//GET ROUTE FOR VIEW
router.get('/show',sessionCheck.sessionChecker,usersControl.show)

//GET ROUTE FOR EDIT  USER
router.get('/edit/:id',usersControl.editUser)

//POST ROUTE FOR EDIT USER
router.post('/edit',usersControl.postedituser)

//GET ROUTE FOR DELETE USER
router.get('/delete-user/:id',usersControl.deleteUser)

//GET ROUTE FOR UPLOAD A FILE
router.get('/fileupload',async (req,res,next)=>{
  const isLoggedIn= req.session.isLoggedIn;
  res.render('fileupload',{title:'FileUpload',isLoggedIn:isLoggedIn})
})

//POST ROUTE FOR FILE UPLOAD
 router.post('/fileupload',usersControl.uploads)


//GET ROUTE FOR ADD CITIES
router.get('/cities',async (req,res,next)=>{
  const isLoggedIn= req.session.isLoggedIn;
  res.render('cities',{title:'Add Cities',isLoggedIn:isLoggedIn})
})
//POST ROUTE FOR ADD STATE
router.post('/cities',usersControl.cities)
//GET ROUTE FOR ADD CITIES
router.get('/states',async (req,res,next)=>{
  const isLoggedIn= req.session.isLoggedIn;
  res.render('states',{title:'Add States',isLoggedIn:isLoggedIn})
})

//POST ROUTE FOR ADD STATE
router.post('/states',usersControl.states)

// ROUTE FOR LOGOUT
router.get('/logout', (req, res, next) => {
  req.session.destroy(() => {
      res.redirect('login');
  });
})



module.exports = router




//VALIDATIONS ON FORM DATA
// [body('email').isEmail()
// .withMessage('Please Enter a Valid Email'),
// body('name').isLength({ min: 3 }),
// body('password').isLength({min:5})
// .withMessage('please enter a password with atleast 5 characters'),
// body('cnfpassword').custom((value,{req})=>{
//   if(value!== req.body.password){
//     throw new Error("Password have to match!");
//   }
//   return true;
// })],
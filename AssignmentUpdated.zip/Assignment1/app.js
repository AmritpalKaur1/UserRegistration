const express=require('express');
const bodyparser=require('body-parser');
const cookieParser = require('cookie-parser');
const session = require('express-session');
const SequelizeStore = require('connect-session-sequelize')(session.Store);
const upload = require("express-fileupload");
var sequelize = require('./util/database')
var users_model = require('./models/usermodel')
var  path = require('path')
var multer = require('multer')
var user_routes = require('./routes/userroute')


const app=express();
const cookie=cookieParser();
app.use(bodyparser.json());
app.use(bodyparser.urlencoded({extended:true}));

app.set('view engine','ejs')
app.set('views','views')

//Multer Coding
// const storageEngine = multer.diskStorage({
// destination:(req,file,cb)=>{
//     cb(null,'./public')
// },
// filename:(req,file,cb)=>{
//     cb(null,file.filename + '-' +file.originalname)
// }
// }) 
// app.use(multer({storage:storageEngine}).array('filesfld',10))

const store = new SequelizeStore({
    db: sequelize
})



// initialize express-session to allow us track the logged-in user across sessions.
app.use(session({
    secret: 'my-secret',
    resave: false,
    saveUninitialized: false,
    store: store
}))

app.use(cookie);
app.use(upload());

 app.use(express.urlencoded({extended:false}))
app.use(express.json());
app.use(express.static('./public'))



//SET ROUTES
app.use('/',user_routes)

/*app.listen(3000,function(){
    console.log("Server Started...");
})*/




sequelize.sync().then(result => {
    app.listen(3000);
}).catch(err =>{
    console.log(err);
});
var Sequelize = require('sequelize')
var sequelize = require('../util/database')

module.exports = sequelize.define('userstate',{

    state:{
        type:Sequelize.STRING
    }
})



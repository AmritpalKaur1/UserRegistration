var Sequelize = require('sequelize')
var sequelize = require('../util/database')

module.exports = sequelize.define('usercity',{

    city:{
        type:Sequelize.STRING
    }
})


var Sequelize = require('sequelize')
var sequelize = require('../util/database')

module.exports = sequelize.define('userinfos',{
    id:{
        type:Sequelize.INTEGER,
        autoIncrement:true,
        primaryKey:true
    },
    name:{
        type:Sequelize.STRING
    },
    age:{
        type:Sequelize.STRING
    },
    gender:{
        type:Sequelize.STRING
    },
    email:{
        type:Sequelize.STRING
    },
    password:{
        type:Sequelize.STRING
    },
   
    phone:{
        type:Sequelize.STRING
    },
   address:{
     type:Sequelize.STRING
   },
   permanent_address:{
    type:Sequelize.STRING
   },
    description:{
        type:Sequelize.STRING
    }
})



var Sequelize = require('sequelize')
var sequelize = require('../util/database')

module.exports = sequelize.define('userimg',{

    img:{
        type:Sequelize.STRING
    }
})



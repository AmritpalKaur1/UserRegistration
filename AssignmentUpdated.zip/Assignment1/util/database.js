var Sequelize = require('sequelize')

var sequelize = new Sequelize('register', 'root', 'Root@123', {
    host: 'localhost',
    dialect: 'mysql',
  });

 
module.exports = sequelize;
	

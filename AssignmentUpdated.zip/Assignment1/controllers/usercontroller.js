var usermodel = require('../models/usermodel');
var imagemodel = require('../models/imagemodel');
var statemodel = require('../models/statemodel');
var citiesmodel = require('../models/citiesmodel');
var multer = require('multer')
var path = require('path')
var sequelize = require('../util/database')
var express = require('express');
const bcrypt = require('bcryptjs');
var app = express();
const cookieParser = require('cookie-parser');
const session = require('express-session');
const SequelizeStore = require('connect-session-sequelize')(session.Store);
//const {validationResult} =require('express-validator/check')





//POST MODULE FOR SIGNUP
exports.home = (req, res) => {

    var name = req.body.name;

    var age = req.body.age;
    var gender = req.body.gender;
    var email = req.body.email;
    var password = req.body.password;
    var cnfpassword = req.body.cnfpassword;
    var phone = req.body.phone;
    //Address
    var street_one = req.body.street_one;
    var street_two = req.body.street_two;
    var near_by = req.body.near_by;
    var city = req.body.city;
    var state = req.body.state;
    /* if(city==='Mohali'||city==='Patiala'||city==='Sangrur'||city==='Ludhiana'||city==='Bathinda'){
             state===Punjab;
     }
     else if(city==='Una'){
         state="Himachal";
     }
     else if(city==='Sirsa')
     {
         state="Haryana"; 
     }
     else if(city==='Hanumangarh')
     {
         state="Rajasthan"; 
     }
     else if(city==='Chandigarh')
     {
         state="Chandigarh"; 
     }*/
    // var imageurl = req.file;
    //Permanent Address
    var p_street_one = req.body.p_street_one;
    var p_street_two = req.body.p_street_two;
    var p_near_by = req.body.p_near_by_two;
    var p_city = req.body.p_city_two;
    var p_state = req.body.p_state_two;
    var description = req.body.description;
    //address in array
    var address = {
        street_one: street_one,
        street_two: street_two,
        nearby: near_by,
        city: city,
        state: state
    }
    //permanent address in array
    var permanent_address = {
        p_street: p_street_one,
        p_street_two: p_street_two,
        p_nearby: p_near_by,
        p_city: p_city,
        p_state: p_state
    }
    // const errors=validationResult(req);
    // if(!errors.isEmpty){
    //     console.log(errors.isEmpty);
    //     const isLoggedIn=req.session.isLoggedIn;
    //     return req.status(422).render('form',{title:'Register',isLoggedIn:isLoggedIn,errorMessage:json({ errors: errors.array() })})
    // }
    //checking error
    //    var errors = [];
    //     if(!name || !age || !gender || !email || !password || !phone || !street_one || !street_two || !near_by || !city || !imageurl || !state)
    //     {
    //        errors.push('Please fill All Fields');
    //          console.log('Please fill All Fields');
    //     }

    //Inserted data into database

    bcrypt.hash(password, 12)
        .then(hashedPassword => {

            return usermodel.create({
                name: name,
                age: age,
                gender: gender,
                email: email,
                phone: phone,
                address: JSON.stringify(address),
                permanent_address: JSON.stringify(permanent_address),
                description: description,
                //image_path:imageurl.path,
                password: hashedPassword
            })
                .then(user => {
                    console.log("Data Inserted....");
                    res.redirect('login');
                })
        })
        .catch(err => {
            console.log(err);
        })

    res.redirect('/show');
}

//POST MODULE FOR FILE UPLOAD
exports.uploads = function (request, response) {
    var images = new Array();

    if (request.files) {
        var arr;
        if (Array.isArray(request.files.filesfld)) {
            arr = request.files.filesfld;
        }
        else {
            arr = new Array(1);
            arr[0] = request.files.filesfld;
        }
        for (var i = 0; i < arr.length; i++) {
            var file = arr[i];
            if (file.mimetype.substring(0, 5).toLowerCase() == "image") {
                images[i] = "/" + file.name;
                file.mv("./public" + images[i], function (err) {
                    if (err) {
                        console.log(err);
                    }
                });
            }
        }
        setTimeout(function () { response.json(images); }, 1000);


        return imagemodel.create({

            img: "./public" + "/" + file.name

        })
            .then(user => {

                console.log("./public" + "/" + file.name + "Image Inserted....");

                response.redirect('show');
            })

            .catch(err => {
                console.log(err);
            })

    }
};

//POST MODULE FOR STATES
exports.states = (req, res, next) => {
    const states = req.body.state;
    console.log("State are:::::::"+req.body.state);
    return statemodel.create({
        state:states
    })
        .then(user => {
            const isLoggedIn=req.session.isLoggedIn;
            res.render('homes',
            {title:'Home',
            isLoggedIn:isLoggedIn,
        user:user});
            res.redirect('/');
            
        })

.catch(err => {
    console.log(err);
})

}

//POST MODULE FOR CITIES
exports.cities = (req, res, next) => {
    const city = req.body.city;
    console.log("Cities  are:::::::"+req.body.city);
    return citiesmodel.create({
        city:city
    })
        .then(user => {
            const isLoggedIn=req.session.isLoggedIn;
            res.send("Successfully Added Cities....")
            
            
        })

.catch(err => {
    console.log(err);
})

}

//FETCH STATES DATA FROM DATABASE TO HOME
exports.homes = (req, res, next) => {
   statemodel.findAll().then(result => {
        const isLoggedIn = req.session.isLoggedIn;
        res.render('homes',
            {
                user: result,
                isLoggedIn: isLoggedIn
            });
    })
  
   
  
   
}
//POST MODULE FOR LOGIN
exports.login = (req, res, next) => {
    const email = req.body.email;
    const password = req.body.password;
    usermodel.findAll({
        where: {
            email: email
        }
    })
        .then(user => {
            const userPassword = user[0].password;
            console.log(password);
            return bcrypt.compare(password, userPassword)
                .then(doMatch => {
                    if (doMatch) {
                        console.log(doMatch)
                        req.session.isLoggedIn = true;
                        req.session.user = user;
                        return req.session.save(err => {
                            console.log(err);
                            res.redirect('/show');
                        })
                    }
                })
                .catch(err => {
                    console.log(err);

                    res.redirect('login');
                })
        })
}

//GET MODULE FOR VIEW
exports.show = (req, res, next) => {
    usermodel.findAll().then(result => {
        const isLoggedIn = req.session.isLoggedIn;
        res.render('show',
            {
                user: result,
                isLoggedIn: isLoggedIn
            });
    })
}

//GET MODULE FOR EDIT USER
exports.editUser = (req, res) => {
    const id = req.params.id
    usermodel.findByPk(id).then(user => {
        var sin = JSON.parse(user.address)
        const isLoggedIn = req.session.isLoggedIn;
        res.render('edit', { user: user, address: sin, isLoggedIn: isLoggedIn })
    })
}

//POST MODULE FOR EDIT USER
exports.postedituser = (req, res, next) => {
    const id = req.body.id;
    const updatedname = req.body.name;
    console.log(updatedname)
    const updatedemail = req.body.email;
    const updatedphone = req.body.phone;
    const updatedage = req.body.age;
    const updatedgender = req.body.gender
    var updateddescription = req.body.description
    //address
    const updatedstreet1 = req.body.street_one
    const updatedstreet2 = req.body.street_two
    var updatednear_by = req.body.near_by
    var updatedcity = req.body.city
    var updatedstate = req.body.state
    // var upimage = req.file
    //Permanent Address
    var u_p_street_one = req.body.p_street_one
    var u_p_street_two = req.body.p_street_two
    var u_p_near_by = req.body.p_near_by_two
    var u_p_city = req.body.p_city_two
    var u_p_state = req.body.p_state_two

    // update address
    var updatedaddress = {
        street_one: updatedstreet1,
        street_two: updatedstreet2,
        nearby: updatednear_by,
        city: updatedcity,
        state: updatedstate
    }
    //update permanent address
    var updatedpermanent_address = {
        p_street: u_p_street_one,
        p_street_two: u_p_street_two,
        p_nearby: u_p_near_by,
        p_city: u_p_city,
        p_state: u_p_state
    }
    usermodel.findByPk(id).then(user => {
        user.name = updatedname,
            user.email = updatedemail,
            user.phone = updatedphone,
            user.age = updatedage,
            user.gender = updatedgender,
            user.description = updateddescription,
            user.address = JSON.stringify(updatedaddress),
            user.permanent_address = JSON.stringify(updatedpermanent_address)
        // user.image_path=upimage.file

        return user.save();
        console.log("Edited,,....");
    })
    res.redirect('/show')

}


//  GET MODULE FOR DELETE A USER
exports.deleteUser = (req, res, next) => {
    const id = req.params.id;
    usermodel.findByPk(id).then(deleteuser => {
        return deleteuser.destroy();
    }).then(result => {
        res.redirect('/show');
    })
}

